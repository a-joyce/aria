package controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

public class MomentsController {
		
	@FXML 
	//This action is called 
	protected void handleMomentButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();	
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Moments1.fxml"));	
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load(); 
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();		
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox)); 									
			
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {		
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}
	
	@FXML 
	protected void handleTipsButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();				
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Tips1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();									
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			Stage stage = new Stage();											
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));									
			
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}
	
	@FXML 
	protected void handleContactButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();				
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Contacts1.fxml"));	
		
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();									
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			Stage stage = new Stage();											
		
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));									
		
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {
			e.printStackTrace();												
		}
	}

	@FXML 
	//This action is called when the X button is pressed, which properly closes the program.
	protected void handleExitProgramButtonAction(ActionEvent event) {
			
		try {
			//This terminates the program.
			System.exit(0);														
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}	
	
	/** Moments Related */
	
	@FXML
	private ComboBox<String> roomChoice;	
	
	@FXML
	private ComboBox<String> timeChoice;	
	
	@FXML 
	//This is the element of a countdown label, an fx:id which is declared from the FXML file.
	private Label countdownLabel;

	StringProperty timeValue = new SimpleStringProperty();

	@FXML 
	//This action is called when the button to book a practice time is pressed, which is outlined in the FXML file "Moments1".
	protected void handleBookRoomButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Moments2.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}
		
	@FXML 
	//This action is called when the button to load the moment page is pressed, which is outlined in the relevant FXML file.
	public void handleBookConfirmButtonAction(ActionEvent event) throws SQLException{
		
		
		
		String dateStamp = new SimpleDateFormat("yyyy.MM.dd").format(Calendar.getInstance().getTime());
		System.out.println(dateStamp);
		
		String timeStamp = new SimpleDateFormat("HH:mm:ss").format(Calendar.getInstance().getTime());
		System.out.println(timeStamp);
				
		Boolean canceled = new Boolean("1");
	
		
		String room = roomChoice.getText();
		String time = timeChoice.getText();
		
		System.out.println(room +" + "+time);
		
		//Tutor Validation
		if(room.isEmpty()) {			
			Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! You haven't picked a practice room .");
	    	alert.showAndWait();
		
		}
			
		//Tutor Validation
		if(time.isEmpty()) {			
			Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! You haven't picked a tutor group.");
	    	alert.showAndWait();
		
		}
		
		//PopUp Confirmation
		
			Alert alert = new Alert(AlertType.CONFIRMATION);
			alert.setTitle("Confirmation Dialog");
			alert.setHeaderText("Confirmation");
			alert.setContentText("Confirm user details?");

			Optional<ButtonType> result = alert.showAndWait();
			
			if (result.get() == ButtonType.OK){
				
				
				//Establishing the MySQL connections.
				Connection myConn = null;
				Statement myStmt = null;
				
				try {
					
					//This is what connects the connection URL, username and password.
					myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/aria?autoReconnect=true&useSSL=false", "root", "password");
					
					
					
					
									
					/**
					 * HERE I WANT TO CALL A METHOD THAT CAN CHECK ROOM AVAILABILITY, THEN RETURN 0-TRUE or 1-FALSE
					 * pref. called checkRoomAvailable
					 */
					
					/**
					 * THEN I WANT TO CALL A METHOD THAT WILL BOOK THE ROOM FOR ME. I'VE STARTED BELOW BUT I'D LIKE TO PUT IT IN ANOTHER CLASS OR SOMETHING.
					 * 
					 * I'm not sure how to let the program know the idStudent - who's using the program currently, as they only input user details when logging in? Maybe save it to a file?
					 * 
					 * pref. called sqlBookRoom
					 */
					
					/**
					 * FINALLY I THEN WANT TO MARK THE ROOM AS UNAVAILABLE, AGAIN USING 0-TRUE or 1-FALSE
					 * 
					 * pref. called sqlRoomAvailable
					 */
					
					
					
					
					
					//This gives the connection statement to execute.
					myStmt = myConn.createStatement();
					
					//Booking the room 
					//This is the string that will be inserted into the MySQl query.
					String sql = "insert into booking " 
							+ " (bookingDate, bookingStartTime, bookingLength, bookingCanceled, idStudent, idRoom)" 
							+ " values ('"+dateStamp+"','"+timeStamp+"', '"+time+"', '"+canceled+"', '"+idStudent+"', '"+room+"')";
					
					//This executes the statement.
					myStmt.execute(sql);
				}
				catch (Exception exc) {
					//This prints what exception has been thrown, and at what line and call stack it occurred.
					exc.printStackTrace();
				}
				
				finally {
					//This closes the connection after the statement has been executed.
					if (myStmt != null) {
						myStmt.close();
					}
					if (myConn != null) {
						myConn.close();
					}
				}
				
				try {
					//Initializes an empty loader which will load elements onto the stage.
					FXMLLoader loader = new FXMLLoader();
					
					//Finds the FXML file and passes it into the loader variable.
					loader.setLocation(Main.class.getResource("view/Moments3.fxml"));
					
					//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
					VBox vbox  = (VBox) loader.load();
					
					//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
					Stage stage = new Stage();
					
					//Load the scene (contents) onto the stage (the window).
					stage.setScene(new Scene(vbox));
					
					//Show the window.
					stage.show();
					
				} catch (Exception e) {
					//This prints what exception has been thrown, and at what line and call stack it occurred.
					e.printStackTrace();
				
				}
			    
			} else {
			    // ... user chose CANCEL or closed the dialog
			}
		

		
		
		/**
		countdownLabel.textProperty().bind(timeValue);
		
		SimpleDateFormat ft = new SimpleDateFormat ("hh : mm : ss");
		
		//countdownLabel.setText(ft.format(time));
		
		Timer timer = new java.util.Timer();

		timer.schedule(new TimerTask() {
		    public void run() {
		         Platform.runLater(new Runnable() {
		            public void run() {
		            // label.update();
		            // javafxcomponent.doSomething();
		            	Date  time = new Date();
		        		//countdownLabel.setText(ft.format(time));
		            	timeValue.setValue(ft.format(time));
		            }
		        });
		    }
		}, 1000, 1000);
		*/
	



	}

	@FXML
	//This action is called when the button to confirm you have reached the practice room is pressed, which is outlined in the relevant FXML files.
	protected void handleBookReachedButtonAction(ActionEvent event) {
		
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Moments1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}
	
	
	
	@FXML 
	//This action is called when the button to cancel the booking is pressed.
	protected void handleBookCancelButtonAction(ActionEvent event) {
		
		//This binds the element timeValue as a text property to countdownLabel.
		countdownLabel.textProperty().bind(timeValue);
		
		//This creates a new SimpleDateFormat, which will show it as eg. '12:03', 12 minutes and 3 seconds.
		SimpleDateFormat ft = new SimpleDateFormat ("mm:ss");
		
		//countdownLabel.setText(ft.format(time));
		
		Timer timer = new java.util.Timer();

		timer.schedule(new TimerTask() {
		    public void run() {
		         Platform.runLater(new Runnable() {
		            public void run() {
		            // label.update();
		            // javafxcomponent.doSomething();
		            	Date  time = new Date();
		        		//countdownLabel.setText(ft.format(time));
		            	timeValue.setValue(ft.format(time));
		            }
		        });
		    }
		}, 1000, 1000);
	}			
}
