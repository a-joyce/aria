package controller;

//import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class OldUserController {
	
	@FXML
	private TextField oldEmail;
	@FXML
	private PasswordField oldPassword;
	
	@FXML
	public void handleUserFromDatatbase(ActionEvent event) throws SQLException {
		
		
		
		String email = oldEmail.getText(); 
		String passw = oldPassword.getText();
		
		System.out.println(email + passw);
		
		//LOGIN Validation
		
		if(!email.isEmpty() && !passw.isEmpty()){	
			
			Connection myConn = null;
			Statement myStmt = null;
			ResultSet myRs = null;
			
			try {
				// 1. Get a connection to database
				myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/aria?autoReconnect=true&useSSL=false", "root" , "password");
				
				// 2. Create a statement
				myStmt = myConn.createStatement();
				
				// 3. Execute SQL query			
				String query1 = "Select userFName from user Where userEmail='"+email+"' and userPass='"+passw+"'";
				myRs = myStmt.executeQuery(query1);
				
				// 4. Process the result set			
				while (myRs.next()) {
					//CHANGE TO POP UP
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setTitle("Welcome");
					alert.setHeaderText(null);
					alert.setContentText("Hey " + myRs.getString("userFName") + "!\n\n(If this isn't you, please close the application and log in again. Thanks!)");

					alert.showAndWait();
				}	
				
			} catch (Exception e) {
				e.printStackTrace();
				Alert alert2 = new Alert(AlertType.ERROR);
		    	alert2.setTitle("Wait Up");
		    	alert2.setHeaderText(null);
		    	alert2.setContentText("Something went wrong! Double check your username and password.");
		    	alert2.showAndWait();
			}
			
			try {
				//Initializes an empty loader which will load elements onto the stage.
				FXMLLoader loader = new FXMLLoader();
				
				//Finds the FXML file and passes it into the loader variable.
				loader.setLocation(Main.class.getResource("view/Moments1.fxml"));
				
				//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
				VBox vbox  = (VBox) loader.load();
				
				//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
				Stage stage = new Stage();
				
				//Load the scene (contents) onto the stage (the window).
				stage.setScene(new Scene(vbox));
				
				//Show the window.
				stage.show();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
						
			finally {
				//This closes the connection & ResultSet functions after the statement has been executed.

				if (myRs != null) {
					myRs.close();
				}
				if (myStmt != null) {
					myStmt.close();
				}
				if (myConn != null) {
					myConn.close();
				}
			}
		}
		else {
			Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! Check your username and password.");
	    	alert.showAndWait();
		}
		
	}

}
