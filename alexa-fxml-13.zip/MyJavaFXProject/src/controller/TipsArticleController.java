package controller;

import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.fxml.Initializable;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.TextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TipsArticleController implements Initializable{
	
	@FXML 
	protected void handleMomentButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Moments1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}
	
	@FXML 
	protected void handleTipsButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Tips1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}
	
	@FXML 
	//This action is called when the button to go to the Contact menu is pressed.
	protected void handleContactButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Contacts1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}

	@FXML 
	//This action is called when the user presses the "x" to close the program.
	protected void handleExitProgramButtonAction(ActionEvent event) {
			
		try {
			//This terminates the program.
			System.exit(0);
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}	
	
	/** Tips Article Controller */
	
	@FXML 
	private TextField tipsText;
		
	//This action is called when the button to load the tips article page is pressed.
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {		
		//This will load the article into the text field.
		
			  
		// get file name
		String filename = arg1.getString("filename");
		
        String text = "";        
	 
		try {

	        // open file
			Scanner fsc = new Scanner(filename);
			
			String line = "";
			
			// read file
			while(fsc.hasNextLine())
			{
				line = fsc.nextLine();
				
				text += line + "\n";
				
			}
			
			fsc.close();
			
            // display file contents
			tipsText.setText(text);

		} catch (Exception e) {

			e.printStackTrace();

		}
		 
	}
	
}
