package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

//.settextwrap true

public class MenuController {
	
	//These ActionEvents are what are called up when an action is called by the FXML file.
	//
	
	@FXML
	//This action is called when the button to load the moment page is pressed, which is outlined in the FXML files "NewUser" and "OldUser" both of which use this controller.
	protected void handleMomentButtonAction(ActionEvent event) {				
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();	
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Moments1.fxml"));	
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load(); 
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();		
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox)); 									
			
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {		
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}
	
	@FXML 
	//This action is called when the button to load the tips page is pressed, which is outlined multiple FXML files.
	protected void handleTipsButtonAction(ActionEvent event) {					
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();				
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Tips1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();									
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			Stage stage = new Stage();											
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));									
			
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}
	
	@FXML 
	//This action is called when the button to load the contact page is pressed, which is outlined multiple FXML files.
	protected void handleContactButtonAction(ActionEvent event) {				
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();				
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Contacts1.fxml"));	
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();									
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			Stage stage = new Stage();											
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));									
			
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}

	@FXML 
	//This action is called when the user presses the "x" to close the program.
	protected void handleExitProgramButtonAction(ActionEvent event) {			
			
		try {
			//This terminates the program.
			System.exit(0);														
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}	
		
	/** Initial Menu Related */
	
	@FXML
	//This action is called when the button to create a new user is pressed, 
	protected void handleNewUserButtonAction(ActionEvent event) {				
		
		
		
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();		
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			loader.setLocation(Main.class.getResource("view/NewUser.fxml"));
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			VBox vbox  = (VBox) loader.load();	
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));									
			
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();  												
		}
	}
	
	@FXML
	//This 
	protected void handleOldUserButtonAction(ActionEvent event) {				
		
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();								
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			loader.setLocation(Main.class.getResource("view/OldUser.fxml"));	
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();									
			
			//Load the scene (contents) onto the stage (the window).
			Stage stage = new Stage();	
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));	
			
			//Show the window.
			stage.show();														
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}		
	}

	@FXML 
	protected void handleTipsArticleButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();

			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/TipsArticle.fxml"));	
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();												
		}
	}
	
	
}

