package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.event.ActionEvent;

public class NewUserController {
	
	@FXML
	//This is the element of a text field label, an fx:id which is declared from the FXML file.
	private TextField userFName;
	
	@FXML
	//This is the element of a text field label, an fx:id which is declared from the FXML file.
	private TextField userEmail;	
	
	@FXML
	//This is the element of a password label, an fx:id which is declared from the FXML file.
	private PasswordField userPass;
	
	@FXML
	//This is the element of a password label, an fx:id which is declared from the FXML file.
	private PasswordField userPass2;
	
	@FXML
	//This is the element of a text field label, an fx:id which is declared from the FXML file.
	private TextField userMobNo;	
	
	@FXML
	//This is the element of a ComboBox input, an fx:id which is declared from the FXML file.
	private ComboBox<String> userTutor;		
	
	@FXML
	//This action is called when the user presses the button to submit their information to create a new user.
	public void handleUsertoDatatbase(ActionEvent event) throws SQLException {
		
		//These are the values from the fx:id's above, in text form.
		
		String name = userFName.getText(); 
		String email = userEmail.getText(); 
		String pass = userPass.getText();
		String pass2 = userPass2.getText();
		String mobno = userMobNo.getText();
		String tutor = userTutor.getValue();
		
		//Name Validation		
		if(name.isEmpty()) {
			
			Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! You've entered an invalid name.");
	    	alert.showAndWait();
		
		}
		
		//Email Validation		
		if(email.isEmpty()) {			
			Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! You've entered an invalid email address.");
	    	alert.showAndWait();
		
		}
		
		//Password Validation
		//If both password inputs match, the info gets saved to a database.
		
		if (pass.equals(pass2)) {
						
	    } else {
	    	
	    	Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! Check your passwords match.");
	    	alert.showAndWait();
	    }		
		
		//Mobile Validation		
		if(mobno.isEmpty()) {			
			Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! You've entered an invalid mobile number.");
	    	alert.showAndWait();
		
		}
		
		//Tutor Validation
		if(tutor.isEmpty()) {			
			Alert alert = new Alert(AlertType.ERROR);
	    	alert.setTitle("Wait Up");
	    	alert.setHeaderText(null);
	    	alert.setContentText("Something went wrong! You haven't picked a tutor group.");
	    	alert.showAndWait();
		
		}
		
		//PopUp Confirmation		
		Alert alert1 = new Alert(AlertType.CONFIRMATION);
		alert1.setTitle("Confirmation Dialog");
		alert1.setHeaderText("Confirmation");
		alert1.setContentText("Confirm user details?");

		Optional<ButtonType> result = alert1.showAndWait();
		
		if (result.get() == ButtonType.OK){
			//Establishing the MySQL connections.
			Connection myConn = null;
			Statement myStmt = null;
			
			try {
				//This is what connects the connection URL, username and password.
				myConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/aria?autoReconnect=true&useSSL=false", "root", "password");
				
				//This gives the connection statement to execute.
				myStmt = myConn.createStatement();
				
				//This is the string that will be inserted into the MySQl query.
				String sql = "insert into user " 
						+ " (userFName, userEmail, userPass, userMobNo, userForm)" 
						+ " values ('"+name+"','"+email+"', '"+pass+"', '"+mobno+"', '"+tutor+"')";
				
				//This executes the statement.
				myStmt.execute(sql);
			}
			catch (Exception exc) {
				//This prints what exception has been thrown, and at what line and call stack it occurred.
				//exc.printStackTrace();
				
				Alert alert2 = new Alert(AlertType.ERROR);
		    	alert2.setTitle("Wait Up");
		    	alert2.setHeaderText(null);
		    	alert2.setContentText("Something went wrong! Please double check your details.");
		    	alert2.showAndWait();
			
			}
			
			finally {
				//This closes the connection after the statement has been executed.
				if (myStmt != null) {
					myStmt.close();
				}
				if (myConn != null) {
					myConn.close();
				}
			}
			
			try {
				//Initializes an empty loader which will load elements onto the stage.
				FXMLLoader loader = new FXMLLoader();
				
				//Finds the FXML file and passes it into the loader variable.
				loader.setLocation(Main.class.getResource("view/Moments1.fxml"));
				
				//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
				VBox vbox  = (VBox) loader.load();
				
				//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
				Stage stage = new Stage();
				
				//Load the scene (contents) onto the stage (the window).
				stage.setScene(new Scene(vbox));
				
				//Show the window.
				stage.show();
				
			} catch (Exception e) {
				//This prints what exception has been thrown, and at what line and call stack it occurred.
				e.printStackTrace();
			}
		    
		} else {
		    // ... user chose CANCEL or closed the dialog
		}
	}	
}