//The controller packages manipulate the scenes dictated by the FXML files in the view package, loading the GUI and making it interactive for the user.

package controller;

//import java.net.URL;
//import java.util.ResourceBundle;
//import javafx.event.ActionEvent;
//import java.fxml.FXML;
//import javafx.fxml.Initializable;
//import javafx.scene.control.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.*;
import javafx.stage.Stage;

       
//This is the first class that runs when the program opens. All it does is open the first FXML file, MenuIntro.
public class Main extends Application {
		
	@Override
	public void start(Stage primaryStage) {
		
		//Sets the window title as Aria, typically in the same bar as the minimize, maximize and close buttons.
		primaryStage.setTitle("Aria");
			
		try {
			
			FXMLLoader loader = new FXMLLoader();			
			
			//Finds the FXML file and loads it into the loader variable.
			loader.setLocation(Main.class.getResource("view/MenuIntro.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox = (VBox) loader.load();
			BorderPane root = new BorderPane();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.
			root.getChildren().add(vbox);
			
			//The scene is what the window actually appears like to you, in this case with a width of 414 and a height of 628.
			Scene scene = new Scene(root,414,628);
			
			//This asks the program to use a CSS file (cascading style-sheets) to format the program, where necessary.
			scene.getStylesheets().add(getClass().getResource("view/BasicApplication.css").toExternalForm());
			
			//Load the scene (contents) onto the stage (the window)
			primaryStage.setScene(scene);
			
			//Show the window
			primaryStage.show();
		
		//If the code for whatever reason doesn't work, the catch will say how to error message will be reported.
		} catch (Exception ex) {
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
	
	//This loads the class, and launches the application.
	public static void main(String[] args) {
		Application.launch(args);
	}
}