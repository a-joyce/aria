package controller;

import java.awt.Desktop;
import java.net.URI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ContactsController {
	
	@FXML 
	//This action is called when the user presses the link to go the moments page.
	protected void handleMomentButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Moments1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}
	
	@FXML 
	protected void handleTipsButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Tips1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}
	
	@FXML 
	protected void handleContactButtonAction(ActionEvent event) {
			
		try {
			//Initializes an empty loader which will load elements onto the stage.
			FXMLLoader loader = new FXMLLoader();
			
			//Finds the FXML file and passes it into the loader variable.
			loader.setLocation(Main.class.getResource("view/Contacts1.fxml"));
			
			//It sets the page up as a Vertical-Box (all elements stack vertically) which is the root node (element) of the FXML files.
			VBox vbox  = (VBox) loader.load();
			
			//This asks the program to take all elements (children) within the FXML and load them into the VBox.										
			Stage stage = new Stage();
			
			//Load the scene (contents) onto the stage (the window).
			stage.setScene(new Scene(vbox));
			
			//Show the window.
			stage.show();
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}

	@FXML 
	protected void handleExitProgramButtonAction(ActionEvent event) {
			
		try {
			//This terminates the program.
			System.exit(0);
			
		} catch (Exception e) {
			//This prints what exception has been thrown, and at what line and call stack it occurred.
			e.printStackTrace();
		}
	}	
	
	/** Contacts Controller*/
	
	@FXML
	//The 1st email account listed
	private Button id1;	
	
	@FXML 
	//The 2nd email account listed
	private Button id2;
	
	@FXML 
	//The 3rd email account listed
	private Button id3;
	
	@FXML
	//The 4th email account listed
	private Button id4;
	
	@FXML
	//The 5th email account listed
	private Button id5;
	
	@FXML 
	//The 6th email account listed
	private Button id6;
	
	@FXML 
	//The 7th email account listed
	private Button id7;
	
	@FXML 
	//The 8th email account listed
	private Button id8;
	
	@FXML 
	//The 9th email account listed
	private Button id9;
	
	@FXML
	//This variable is taken from the fx:id name of the various music contacts.
	private String emailvariable;
		
	
	@FXML
	//Email option 
	protected void handleContactEmailButtonAction(ActionEvent event) {
			
		try {
			//Opens the desktop from which we can open the mail client.
			Desktop desktop = Desktop.getDesktop();
			
			//Takes the email variable and creates a to line and a subject line using the given email address.
			String message = "mailto:"+emailvariable+"@britishschool.sch.ae?subject=Music%20Bookings";
			
			//Creates a message from the string given above.
			URI uri = URI.create(message);
			
			//Opens the mail client, with the message as the "to:" and "Subject" sections.
			desktop.mail(uri);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}


